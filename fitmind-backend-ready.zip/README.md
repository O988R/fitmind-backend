# FitMind Backend

Production-ready backend for FitMind App.